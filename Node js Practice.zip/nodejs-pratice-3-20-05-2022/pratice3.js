const { query } = require("express");
const express=require("express");
const app=express();

app.get('',(req,res)=>
{
    res.send("This is normal msg without any parameters");   //normal get method
})

app.get('/hello',(req,res)=>
{
    res.send("This is msg with hello parameter");         //get method with hello as parameter
})

/*const greet1=(req,res)=>
{
    console.log("req params are : ",req.params);
    let {name} =req.params;
    res.send(`hello ${name}`);
}*/

const greet2=(req,res)=>
{
    console.log("req params are : ",req.params);
    let {name,degree} =req.params;
    res.send(`hello ${name} with ${degree}`);
}

//app.get('/hello/:name',greet1);         //method by passing parameters  declared a sepaarte function and using it
app.get('/hello/:name/:degree',greet2); 

//query parameters
const greeting=(req,res)=>
{
    console.log("query params are : ",req.query);
    let {name} =req.query;
    res.send(`HI ${name}`);
}

app.get('/hi',greeting);

app.listen(5000,()=>
{
    console.log("Server is running at port 5000");
})