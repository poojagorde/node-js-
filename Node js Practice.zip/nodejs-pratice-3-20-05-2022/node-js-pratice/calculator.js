const add =(n1,n2) =>
{
    let res=n1+n2;
    console.log("Addition of numbers is "+res);
}
const sub =(n1,n2) =>
{
    let res=n1-n2;
    console.log("Subtraction of numbers is "+res);
}
const mul =(n1,n2) =>
{
    let res=n1*n2;
    console.log("Multiplication of numbers is "+res);
}
const div =(n1,n2) =>
{
    let res=n1/n2;
    console.log("Division of numbers is "+res);
}
console.log("-----Menu------");
console.log("1.Addition");
console.log("2.Subtraction");
console.log("3.Multiplication");
console.log("4.Division");
const Calculator =() =>
{
    let opt=parseInt(process.argv[2]);
    let n1=parseInt(process.argv[3]);
    let n2=parseInt(process.argv[4]);
    switch(opt)
    {
        case 1:add(n1,n2);
               break;
        case 2:sub(n1,n2);
               break;
        case 3:mul(n1,n2);
               break;
        case 4:div(n1,n2);
               break;
        default:console.log("Enter option from menu ....");
    }
}
Calculator();